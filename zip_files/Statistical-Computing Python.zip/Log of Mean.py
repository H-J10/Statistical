# Python
import math
numbers = [1, 10, 100]
log_mean = math.log(sum(numbers)/len(numbers))
print(log_mean)
