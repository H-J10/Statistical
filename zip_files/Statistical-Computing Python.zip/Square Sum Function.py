# Python
def square_sum(x, y):
    return x**2 + y**2

print(square_sum(3, 4))  # Output: 25
