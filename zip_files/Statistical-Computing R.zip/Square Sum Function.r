# R
square_sum <- function(a, b) {
  a^2 + b^2
}
print(square_sum(3, 4))  # Output: 25
