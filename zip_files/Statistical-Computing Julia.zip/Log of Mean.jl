# Julia
numbers = [1, 10, 100]
log_mean = log(mean(numbers))
println(log_mean)
