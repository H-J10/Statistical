# Julia
is_smaller(a, b) = a < b
println(is_smaller(3, 5))  # Output: true
