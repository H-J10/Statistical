# Julia
mean_of_list(lst) = mean(lst)
println(mean_of_list([2, 4, 6, 8]))  # Output: 5.0
