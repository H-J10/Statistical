# Julia
square_sum(a, b) = a^2 + b^2
println(square_sum(3, 4))  # Output: 25
