# Julia
remainder(a, b) = mod(a, b)
println(remainder(17, 5))  # Output: 2
