# Python
def remainder(a, b):
    return a % b
    
#Expected Output: 2
print(remainder(17, 5))  #    Output: 2
