# Python
def mean_of_list(lt):
    return sum(lt)/len(lt)

print(mean_of_list([2, 4, 6, 8]))  # Output: 5.0
