# Python
def is_smaller(a, b):
    return a < b

print(is_smaller(3, 5))  # Output: True
