# R
is_smaller <- function(a, b) {
  a < b
}
print(is_smaller(3, 5))  # Output: TRUE
