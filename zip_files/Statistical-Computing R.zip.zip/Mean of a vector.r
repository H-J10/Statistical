# R
mean_of_list <- function(lst) {
  mean(lst)
}
print(mean_of_list(c(2, 4, 6, 8)))  # Output: 5
