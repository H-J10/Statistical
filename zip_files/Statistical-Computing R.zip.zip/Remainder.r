# R
remainder <- function(a, b) {
  a %% b
}
print(remainder(17, 5))  # Output: 2
