# R
numbers <- c(1, 10, 100)
log_mean <- log(mean(numbers))
print(log_mean)
